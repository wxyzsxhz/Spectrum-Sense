import React from "react";

export const Logo = ({ className }: { className?: string }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 64 64"
      fill="none"
      className={className}
    >
      <circle cx="32" cy="32" r="32" fill="#F38081" /> {/* Coral Reef circle */}
      <path
        d="M32 16 L40 48 L32 40 L24 48 Z"
        fill="#EFD780" /> {/* Meyer Lemon arrow / abstract ASD icon */}
    </svg>
  );
};
