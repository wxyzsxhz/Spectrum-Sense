import Link from "next/link";
import { Mail, Phone, MapPin, Heart } from "lucide-react";

const footerLinks = {
  quickLinks: [
    { name: "Home", href: "/" },
    { name: "Check Risk", href: "/check" },
    { name: "Dashboard", href: "/dashboard" },
    { name: "Articles", href: "/article" },
  ],
  resources: [
    { name: "About ASD", href: "/about" },
    { name: "Research", href: "/research" },
    { name: "FAQs", href: "/faqs" },
    { name: "Support Groups", href: "/support" },
  ],
  legal: [
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Terms of Service", href: "/terms" },
    { name: "Disclaimer", href: "/disclaimer" },
    { name: "Cookie Policy", href: "/cookies" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-accent flex items-center justify-center">
                <svg
                  viewBox="0 0 40 40"
                  className="w-6 h-6 text-accent-foreground"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                >
                  <circle cx="20" cy="20" r="8" />
                  <path d="M20 4v6M20 30v6M4 20h6M30 20h6" strokeLinecap="round" />
                  <path d="M9.5 9.5l4.2 4.2M26.3 26.3l4.2 4.2M9.5 30.5l4.2-4.2M26.3 13.7l4.2-4.2" strokeLinecap="round" />
                </svg>
              </div>
              <span className="font-display font-bold text-xl text-background">ASD Risk</span>
            </Link>
            <p className="text-background/70 text-sm leading-relaxed mb-4">
              Empowering parents and healthcare professionals with early ASD awareness tools. 
              Together, we can support every child's unique journey.
            </p>
            <div className="flex items-center gap-2 text-sm text-background/70">
              <Heart className="w-4 h-4 text-accent" />
              Made with care for families
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display font-semibold text-lg mb-4 text-background">Quick Links</h3>
            <ul className="space-y-3">
              {footerLinks.quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-background/70 hover:text-accent transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-display font-semibold text-lg mb-4 text-background">Resources</h3>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-background/70 hover:text-accent transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Legal */}
          <div>
            <h3 className="font-display font-semibold text-lg mb-4 text-background">Contact</h3>
            <ul className="space-y-3 mb-6">
              <li className="flex items-center gap-2 text-background/70 text-sm">
                <Mail className="w-4 h-4 text-accent" />
                support@asdrisk.com
              </li>
              <li className="flex items-center gap-2 text-background/70 text-sm">
                <Phone className="w-4 h-4 text-accent" />
                1-800-ASD-HELP
              </li>
              <li className="flex items-start gap-2 text-background/70 text-sm">
                <MapPin className="w-4 h-4 text-accent mt-0.5" />
                Healthcare District,<br />City, State 12345
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-background/20 mt-10 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-background/60 text-sm">
              © {new Date().getFullYear()} ASD Risk Analysis. All rights reserved.
            </p>
            <div className="flex flex-wrap gap-4 md:gap-6">
              {footerLinks.legal.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-background/60 hover:text-accent transition-colors text-sm"
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
