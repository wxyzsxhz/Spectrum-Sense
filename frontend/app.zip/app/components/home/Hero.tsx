import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, AlertCircle } from "lucide-react";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url(/landing.jpg)" }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/60 to-background/90" />
      </div>

      {/* Content */}
      <div className="container relative z-10 px-4 lg:px-8 py-16 lg:py-24">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/80 border border-secondary text-secondary-foreground text-sm font-medium mb-6 animate-fade-in">
            <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
            Early Detection Matters
          </div>

          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6 animate-fade-in">
            Understanding <span className="text-accent">ASD</span> Risk Analysis
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-6 animate-fade-in">
            Autism Spectrum Disorder (ASD) affects how individuals perceive and interact with the world.
            Our tool helps parents, guardians, and healthcare professionals identify potential signs early.
          </p>

          <div className="flex items-start gap-3 bg-primary/20 border border-primary/40 rounded-xl p-4 mb-8 text-left animate-fade-in">
            <AlertCircle className="w-5 h-5 mt-0.5" />
            <p className="text-sm">
              <strong>Important:</strong> This tool is for awareness only, not a medical diagnosis.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Button variant="cta" size="xl">
              Check ASD Risk <ArrowRight />
            </Button>
            <Button variant="ctaSecondary" size="xl">
              <BookOpen /> Learn More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
